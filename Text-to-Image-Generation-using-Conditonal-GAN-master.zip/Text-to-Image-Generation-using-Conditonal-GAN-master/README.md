# Text-to-Image-Generation-using-Conditonal-GAN
Generating images of clothes by taking the text descriptions of the clothes as input using the Conditional Generative Adversarial Networks


![alt text](https://github.com/Charan1010/Text-to-Image-Generation-using-Conditonal-GAN/blob/master/cond_gan.png)
